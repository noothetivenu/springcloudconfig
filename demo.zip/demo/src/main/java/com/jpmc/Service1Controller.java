package com.jpmc;

import java.lang.invoke.MethodHandles;
import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Service1Controller {
	
	private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	private final Service2Client service2Client;

	public Service1Controller(Service2Client service2Client) {
		this.service2Client = service2Client;
	}

	@RequestMapping("/start")
	public String start() throws InterruptedException 
	{
	
		log.error("Log Message...from Service1 Controller.....");
		System.out.println("in controller..........");
		
		return "Hello";
	}

	@RequestMapping("/readtimeout")
	public String timeout() throws InterruptedException {
		return service2Client.timeout(LocalDateTime.now().toString());
	}
}
