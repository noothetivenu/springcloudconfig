package com.jpmc;

public class Test 
{
	
	public String name="Ram";
	
	
	public String toString()
	{
		return name;
	}
	

}
